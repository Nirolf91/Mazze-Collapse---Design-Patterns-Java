package main.mazecollapse.commands;

// Interfața Command
public interface Command {
    void execute();
}

// Comanda de mutare la stânga


// Comanda de mutare la dreapta


// Clasa Player cu metodele de mișcare


// Clasa care gestionează input-ul

