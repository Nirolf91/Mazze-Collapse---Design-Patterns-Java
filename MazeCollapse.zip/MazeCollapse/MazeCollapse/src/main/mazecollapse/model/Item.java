package main.mazecollapse.model;

public class Item {
}
