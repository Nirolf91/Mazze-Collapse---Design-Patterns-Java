package main.mazecollapse.model;

public class GameEvent {
}
